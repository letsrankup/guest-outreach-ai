# 🦅 FALCON — King of Rind Outreach AI Engine

**Autonomous Guest Outreach AI Agent & Negotiator Engine**  
Powered by Google Gemini 2.5 Flash · FastAPI · Vanilla JS

---

## 📁 Project Structure

```
falcon-outreach/
├── backend/
│   ├── main.py                  # FastAPI app entry point
│   ├── requirements.txt         # Python dependencies (Vercel)
│   ├── core/
│   │   └── gemini_client.py     # Gemini 2.5 Flash singleton client
│   ├── schemas/
│   │   └── models.py            # Pydantic request/response models
│   └── api/v1/
│       ├── campaign.py          # POST /api/v1/start-campaign
│       └── negotiate.py         # POST /api/v1/negotiate
├── frontend/
│   └── index.html               # Complete dashboard (Tailwind CDN)
├── vercel.json                  # Vercel serverless config
├── netlify.toml                 # Netlify deploy config
└── README.md
```

---

## 🚀 Deployment

### 1 — Backend on Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# From project root
vercel

# Add environment variable via Vercel dashboard or CLI:
vercel env add GEMINI_API_KEY
# Paste your key when prompted, select all environments
```

**Important settings in Vercel dashboard:**
- Root directory: ` ` (project root)
- Build command: *(leave blank)*
- Output directory: *(leave blank)*
- `vercel.json` handles routing automatically.

### 2 — Frontend on Netlify

1. Push repo to GitHub
2. Connect repo in Netlify dashboard
3. Set **Base directory** to `frontend`
4. Set **Publish directory** to `frontend`
5. **Update `API_BASE`** in `frontend/index.html`:

```js
// Line ~330 in index.html
const API_BASE = window.location.hostname === 'localhost'
  ? 'http://localhost:8000'
  : 'https://YOUR-BACKEND.vercel.app';   // ← Replace this
```

---

## 🔑 Environment Variables

| Variable        | Where to set      | Description                    |
|-----------------|-------------------|--------------------------------|
| `GEMINI_API_KEY`| Vercel dashboard  | Google AI Studio API key       |

Get your key at: https://aistudio.google.com/app/apikey

---

## 💻 Local Development

```bash
# Backend
cd backend
pip install -r requirements.txt
export GEMINI_API_KEY="your-key-here"
uvicorn main:app --reload --port 8000

# Frontend — just open in browser
open frontend/index.html
# Or serve with any static server:
npx serve frontend
```

API docs available at: http://localhost:8000/api/docs

---

## 📡 API Reference

### `POST /api/v1/start-campaign`
Launch an autonomous outreach campaign.

```json
{
  "niche": "SaaS productivity tools",
  "target_da": 40,
  "max_budget": 500.0,
  "outreach_volume": 10,
  "tone": "professional"
}
```

Returns `202 Accepted` immediately. Poll logs via:  
`GET /api/v1/campaign/{campaign_id}/logs`

---

### `POST /api/v1/negotiate`
Analyse a publisher email and generate negotiation intelligence.

```json
{
  "email_body": "Hi, we can offer a DA55 placement for $350...",
  "our_budget": 250.0,
  "niche": "SEO tools"
}
```

Returns structured JSON:
```json
{
  "is_interested": true,
  "price_quoted": 350.0,
  "sentiment": "positive",
  "urgency_level": "medium",
  "suggested_corporate_reply": "Dear [Publisher]...",
  "negotiation_strategy": "Counter at $200, anchor on volume...",
  "deal_probability_pct": 78,
  "red_flags": [],
  "key_talking_points": ["Long-term partnership", "Volume discount"]
}
```

---

## 🛠 Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| AI Engine | Google Gemini 2.5 Flash           |
| Backend   | FastAPI + Python 3.11             |
| Schemas   | Pydantic v2                       |
| Frontend  | HTML5 + Tailwind CSS + Vanilla JS |
| Backend hosting | Vercel Serverless           |
| Frontend hosting | Netlify Static             |

---

## ⚡ Future Enhancements (Roadmap)

- [ ] Redis for persistent campaign state (replace in-memory dict)
- [ ] WebSocket live log streaming (replace polling)
- [ ] Supabase / PostgreSQL for campaign history
- [ ] Email sending via SendGrid / Resend
- [ ] Webhook callbacks on campaign completion
- [ ] Multi-user auth via Clerk / Supabase Auth
- [ ] Campaign analytics charts (Chart.js)
- [ ] Export negotiation reports to PDF

---

Built with 🦅 by King of Rind / Falcon Services
