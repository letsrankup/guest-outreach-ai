"""
api/v1/negotiate.py
POST /api/v1/negotiate — AI email analysis & negotiation engine
Uses Gemini structured JSON output matched against NegotiateResponse schema.
"""

from __future__ import annotations
import logging
from fastapi import APIRouter, HTTPException

from schemas.models import NegotiateRequest, NegotiateResponse
from core.gemini_client import generate_json

router = APIRouter()
logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """
You are FALCON — an elite AI negotiation agent for a premium content marketing agency 
called "King of Rind / Falcon Services". You specialise in guest post and link-building 
deals.

Your job: analyse an inbound publisher email and return a precise JSON negotiation 
assessment. Be strategic, cold-blooded, and commercially sharp.

Always return ONLY a valid JSON object with these exact keys:
{
  "is_interested": <bool>,
  "price_quoted": <float>,
  "sentiment": <"positive"|"neutral"|"negative"|"unclear">,
  "urgency_level": <"high"|"medium"|"low">,
  "suggested_corporate_reply": <string — complete ready-to-send professional email>,
  "negotiation_strategy": <string — internal tactical recommendation>,
  "deal_probability_pct": <int 0-100>,
  "red_flags": <array of strings>,
  "key_talking_points": <array of strings>
}
""".strip()


def _build_user_prompt(req: NegotiateRequest) -> str:
    prior_str = ""
    if req.prior_offers:
        prior_str = f"\nPrior offers discussed: {req.prior_offers}"

    return f"""
PUBLISHER EMAIL:
---
{req.email_body}
---

OUR CONTEXT:
- Niche: {req.niche}
- Our maximum budget: ${req.our_budget:.2f} USD
{prior_str}

Analyse the email above and provide your complete negotiation assessment.
For "suggested_corporate_reply", write a polished, complete reply email we can send 
immediately — professional tone, subtly assertive, don't reveal our max budget.
For "negotiation_strategy", give us your honest internal tactical recommendation.
""".strip()


@router.post("/negotiate", response_model=NegotiateResponse)
async def negotiate(req: NegotiateRequest):
    """
    Analyse an inbound publisher email and return:
    - Structured deal intelligence (interest level, price, sentiment)
    - A ready-to-send corporate reply
    - Internal negotiation strategy
    - Risk flags and talking points
    """
    try:
        raw = await generate_json(
            prompt=_build_user_prompt(req),
            system=SYSTEM_PROMPT,
        )
    except ValueError as exc:
        logger.error("JSON parse error from Gemini: %s", exc)
        raise HTTPException(
            status_code=502,
            detail=f"AI returned malformed JSON. Try again. Detail: {exc}",
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))

    # Validate & coerce via Pydantic
    try:
        result = NegotiateResponse(**raw)
    except Exception as exc:
        logger.error("Schema validation failed: %s | raw=%s", exc, raw)
        raise HTTPException(
            status_code=502,
            detail=f"AI response didn't match expected schema: {exc}",
        )

    logger.info(
        "Negotiation complete — interested=%s price=%.2f probability=%d%%",
        result.is_interested, result.price_quoted, result.deal_probability_pct
    )
    return result
