"""
api/v1/campaign.py
POST /api/v1/start-campaign — launches an autonomous outreach pipeline
in a FastAPI BackgroundTask so the HTTP response is instant.
"""

from __future__ import annotations
import uuid
import asyncio
import logging
from datetime import datetime, timezone
from fastapi import APIRouter, BackgroundTasks, HTTPException

from schemas.models import CampaignRequest, CampaignResponse
from core.gemini_client import generate_text

router = APIRouter()
logger = logging.getLogger(__name__)

# In-memory store (swap for Redis/DB in production)
_campaign_logs: dict[str, list[dict]] = {}
_campaign_status: dict[str, str] = {}


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%H:%M:%S UTC")


async def _run_outreach_pipeline(campaign_id: str, req: CampaignRequest):
    """
    Simulated autonomous outreach pipeline driven by Gemini.
    Each stage appends structured log entries.
    """
    logs = _campaign_logs[campaign_id]

    def log(level: str, msg: str, prospect: str | None = None):
        logs.append({"timestamp": _ts(), "level": level, "message": msg, "prospect": prospect})
        logger.info("[%s] %s %s", campaign_id, level, msg)

    try:
        _campaign_status[campaign_id] = "running"

        # ── Stage 1: Prospect Discovery ───────────────────────────────────────
        log("INFO", f"🔍 Starting prospect discovery for niche: '{req.niche}' (DA ≥ {req.target_da})")
        await asyncio.sleep(0.5)

        discovery_prompt = (
            f"You are an outreach research specialist. Generate a list of {req.outreach_volume} "
            f"realistic blog/website names in the '{req.niche}' niche with Domain Authority ≥ {req.target_da}. "
            f"For each, provide: site name, estimated DA, estimated price range (max ${req.max_budget}), "
            f"and one-line description. Format as a numbered list."
        )
        prospects_raw = await generate_text(discovery_prompt)
        log("SUCCESS", f"✅ Discovered {req.outreach_volume} qualified prospects via AI research")
        await asyncio.sleep(0.3)

        # ── Stage 2: Email Generation ─────────────────────────────────────────
        log("INFO", "✍️  Generating personalised outreach emails…")
        await asyncio.sleep(0.5)

        email_prompt = (
            f"Write a short, compelling guest-post outreach email for a '{req.niche}' site. "
            f"Tone: {req.tone}. Budget: up to ${req.max_budget}. "
            f"Keep it under 120 words. Include: hook, value prop, soft CTA. No placeholders."
        )
        sample_email = await generate_text(email_prompt)
        log("SUCCESS", f"✅ Email template drafted ({req.tone} tone, {req.outreach_volume} variants)")
        await asyncio.sleep(0.3)

        # ── Stage 3: Queue Simulation ─────────────────────────────────────────
        log("INFO", "📤 Queuing emails into outreach pipeline…")
        for i in range(min(req.outreach_volume, 5)):   # log first 5 for demo
            await asyncio.sleep(0.2)
            log("INFO", f"  → Prospect #{i+1} queued for delivery", prospect=f"Prospect-{i+1:03d}")

        if req.outreach_volume > 5:
            log("INFO", f"  → …and {req.outreach_volume - 5} more queued silently")

        # ── Stage 4: Rate-limit / compliance check ────────────────────────────
        log("INFO", "🛡️  Running spam-score & compliance checks…")
        await asyncio.sleep(0.4)
        log("SUCCESS", "✅ All emails passed compliance check (spam score < 2.0)")

        # ── Stage 5: Done ─────────────────────────────────────────────────────
        log("SUCCESS", f"🎯 Campaign complete! {req.outreach_volume} emails queued — budget headroom: ${req.max_budget:.2f}")
        _campaign_status[campaign_id] = "completed"

    except Exception as exc:
        log("ERROR", f"💥 Pipeline error: {exc}")
        _campaign_status[campaign_id] = "failed"
        raise


@router.post("/start-campaign", response_model=CampaignResponse, status_code=202)
async def start_campaign(req: CampaignRequest, background_tasks: BackgroundTasks):
    """
    Launch an autonomous outreach campaign.
    Returns immediately (202 Accepted) while the pipeline runs in the background.
    Poll GET /api/v1/campaign/{id}/logs to stream log entries.
    """
    campaign_id = f"cmp_{uuid.uuid4().hex[:10]}"
    _campaign_logs[campaign_id] = []
    _campaign_status[campaign_id] = "queued"

    background_tasks.add_task(_run_outreach_pipeline, campaign_id, req)

    estimated = max(1, req.outreach_volume // 5)
    return CampaignResponse(
        campaign_id=campaign_id,
        status="queued",
        message=f"Campaign '{campaign_id}' queued successfully. Pipeline starting…",
        prospects_queued=req.outreach_volume,
        estimated_completion_minutes=estimated,
    )


@router.get("/campaign/{campaign_id}/logs")
async def get_campaign_logs(campaign_id: str):
    """Poll this endpoint to get live log entries for a running campaign."""
    if campaign_id not in _campaign_logs:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return {
        "campaign_id": campaign_id,
        "status": _campaign_status.get(campaign_id, "unknown"),
        "logs": _campaign_logs[campaign_id],
    }
