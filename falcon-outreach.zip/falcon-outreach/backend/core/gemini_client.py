"""
core/gemini_client.py
Singleton wrapper around google-genai SDK.
Uses GEMINI_API_KEY from environment — set this in Vercel dashboard.
"""

import os
import json
import logging
from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

_client: genai.Client | None = None


def get_client() -> genai.Client:
    """Return a cached Gemini client, initialised on first call."""
    global _client
    if _client is None:
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError(
                "GEMINI_API_KEY environment variable is not set. "
                "Add it to your Vercel project settings → Environment Variables."
            )
        _client = genai.Client(api_key=api_key)
        logger.info("Gemini client initialised (gemini-2.5-flash)")
    return _client


MODEL = "gemini-2.5-flash"


async def generate_text(prompt: str, system: str = "") -> str:
    """Simple text generation helper."""
    client = get_client()
    cfg = types.GenerateContentConfig(
        system_instruction=system if system else None,
        temperature=0.7,
        max_output_tokens=2048,
    )
    response = client.models.generate_content(
        model=MODEL,
        contents=prompt,
        config=cfg,
    )
    return response.text


async def generate_json(prompt: str, system: str = "") -> dict:
    """
    JSON-mode generation — returns a parsed dict.
    Forces the model to respond with valid JSON only.
    """
    client = get_client()
    json_system = (
        (system + "\n\n" if system else "")
        + "IMPORTANT: Respond ONLY with a valid JSON object. "
          "No markdown, no code fences, no explanation — raw JSON only."
    )
    cfg = types.GenerateContentConfig(
        system_instruction=json_system,
        temperature=0.3,          # lower temp for structured output consistency
        max_output_tokens=1024,
        response_mime_type="application/json",
    )
    response = client.models.generate_content(
        model=MODEL,
        contents=prompt,
        config=cfg,
    )
    raw = response.text.strip()
    # Belt-and-suspenders: strip accidental fences
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    return json.loads(raw)
