"""
Falcon Services — Autonomous Guest Outreach AI Agent & Negotiator Engine
FastAPI Backend — Vercel Serverless Compatible
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.v1 import campaign, negotiate

app = FastAPI(
    title="Falcon Services — Outreach AI Engine",
    description="Autonomous Guest Outreach AI Agent & Negotiator powered by Gemini 2.5 Flash",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Lock this down in production to your Netlify URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(campaign.router,  prefix="/api/v1", tags=["Campaign"])
app.include_router(negotiate.router, prefix="/api/v1", tags=["Negotiator"])


@app.get("/", tags=["Health"])
async def root():
    return {
        "service": "Falcon Services — Outreach AI Engine",
        "brand":   "KING OF RIND",
        "status":  "operational",
        "version": "1.0.0",
    }


@app.get("/api/health", tags=["Health"])
async def health():
    return {"status": "ok"}
