"""
schemas/models.py
All Pydantic request / response models for the Falcon Outreach Engine.
"""

from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, Field


# ── Campaign ──────────────────────────────────────────────────────────────────

class CampaignRequest(BaseModel):
    niche: str = Field(..., example="SaaS productivity tools", description="Target content niche")
    target_da: int = Field(..., ge=1, le=100, example=40, description="Minimum Domain Authority")
    max_budget: float = Field(..., gt=0, example=500.0, description="Maximum spend per placement (USD)")
    outreach_volume: int = Field(default=10, ge=1, le=100, description="Number of prospects to target")
    tone: Literal["professional", "friendly", "assertive"] = Field(default="professional")


class CampaignResponse(BaseModel):
    campaign_id: str
    status: str
    message: str
    prospects_queued: int
    estimated_completion_minutes: int


class CampaignLogEntry(BaseModel):
    timestamp: str
    level: Literal["INFO", "SUCCESS", "WARN", "ERROR"]
    message: str
    prospect: str | None = None


# ── Negotiator ────────────────────────────────────────────────────────────────

class NegotiateRequest(BaseModel):
    email_body: str = Field(..., min_length=10, description="Raw email text from the publisher")
    our_budget: float = Field(..., gt=0, description="Our maximum budget for this placement (USD)")
    niche: str = Field(default="general", description="Content niche context")
    prior_offers: list[float] | None = Field(default=None, description="Prior price points discussed")


class NegotiateResponse(BaseModel):
    is_interested: bool = Field(..., description="True if publisher appears interested in a deal")
    price_quoted: float = Field(..., description="Price publisher quoted; 0 if not mentioned")
    sentiment: Literal["positive", "neutral", "negative", "unclear"]
    urgency_level: Literal["high", "medium", "low"]
    suggested_corporate_reply: str = Field(..., description="Ready-to-send professional reply email")
    negotiation_strategy: str = Field(..., description="Internal strategic recommendation for next step")
    deal_probability_pct: int = Field(..., ge=0, le=100, description="Estimated % chance of closing")
    red_flags: list[str] = Field(default_factory=list, description="Any concerns detected in the email")
    key_talking_points: list[str] = Field(default_factory=list, description="Leverage points to use in reply")
